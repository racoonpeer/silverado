#SXD20|20011|50542|50526|2017.08.27 10:51:56|silverado|0|0|0|
#PR sync_product_kits
#FU count_treepath_levels
#EOH

#	PR`sync_product_kits`cp1251_general_ci	;
CREATE PROCEDURE `sync_product_kits`(productID INT(11))
BEGIN
	DECLARE isKit, hasKit INT DEFAULT 0;
	SELECT COUNT(*) INTO isKit FROM `catalog_kits` 
	WHERE `pid`=productID;
	SELECT COUNT(*) INTO hasKit FROM `catalog_kits` 
	WHERE `kid`=productID;
	UPDATE `ru_catalog` SET
		`is_kit` = IF(isKit > 0 AND hasKit = 0, 1, 0), 
		`has_kit` = IF(hasKit > 0 AND isKit = 0, 1, 0) 
		WHERE `id`=productID;
END	;
#	FU`count_treepath_levels`cp1251_general_ci	;
CREATE FUNCTION `count_treepath_levels`(treepath VARCHAR(255), separ CHAR(1)) RETURNS int(11)
    DETERMINISTIC
BEGIN
 DECLARE iLevels, iLength INT DEFAULT 0;
    SET iLength = LENGTH(treepath);
    IF iLength > 0 THEN
      SET iLevels = iLength - LENGTH(REPLACE(treepath, separ, ""));
    END IF;
  RETURN iLevels;
END	;
