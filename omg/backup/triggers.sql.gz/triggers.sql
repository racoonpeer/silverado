#SXD20|20011|50542|50526|2017.08.27 10:51:50|silverado|0|0|0|
#TR catalog_kits_ai|catalog_kits_ad|comments_ai|comments_au|comments_ad|order_products_ai
#EOH

#	TR`catalog_kits_ai`cp1251_general_ci	;
CREATE TRIGGER `catalog_kits_ai` AFTER INSERT ON `catalog_kits` FOR EACH ROW BEGIN
  CALL sync_product_kits(NEW.`pid`);
  CALL sync_product_kits(NEW.`kid`);
END	;
#	TR`catalog_kits_ad`cp1251_general_ci	;
CREATE TRIGGER `catalog_kits_ad` AFTER DELETE ON `catalog_kits` FOR EACH ROW BEGIN
  CALL sync_product_kits(OLD.`pid`);
  CALL sync_product_kits(OLD.`kid`);
END	;
#	TR`comments_ai`cp1251_general_ci	;
CREATE TRIGGER `comments_ai` AFTER INSERT ON `comments` FOR EACH ROW BEGIN
  	UPDATE `ru_catalog` 
	SET `comments_count`=(SELECT COUNT(*) FROM `comments` c WHERE c.`pid`=NEW.`pid` AND c.`active`>0 AND c.`isnew`=0),
		`rating`=(SELECT AVG(`rating`) FROM `comments` c WHERE c.`pid`=NEW.`pid` AND c.`active`>0 AND c.`isnew`=0) 
	WHERE `id`=NEW.`pid`;
END	;
#	TR`comments_au`cp1251_general_ci	;
CREATE TRIGGER `comments_au` AFTER UPDATE ON `comments` FOR EACH ROW BEGIN
  	UPDATE `ru_catalog` 
	SET `comments_count`=(SELECT COUNT(*) FROM `comments` c WHERE c.`pid`=NEW.`pid` AND c.`active`>0 AND c.`isnew`=0),
		`rating`=(SELECT AVG(`rating`) FROM `comments` c WHERE c.`pid`=NEW.`pid` AND c.`active`>0 AND c.`isnew`=0) 
	WHERE `id`=NEW.`pid`;
END	;
#	TR`comments_ad`cp1251_general_ci	;
CREATE TRIGGER `comments_ad` AFTER DELETE ON `comments` FOR EACH ROW BEGIN
  	UPDATE `ru_catalog` 
	SET `comments_count`=(SELECT COUNT(*) FROM `comments` c WHERE c.`pid`=OLD.`pid` AND c.`active`>0 AND c.`isnew`=0),
		`rating`=(SELECT AVG(`rating`) FROM `comments` c WHERE c.`pid`=OLD.`pid` AND c.`active`>0 AND c.`isnew`=0) 
	WHERE `id`=OLD.`pid`;
END	;
#	TR`order_products_ai`cp1251_general_ci	;
CREATE TRIGGER `order_products_ai` AFTER INSERT ON `order_products` FOR EACH ROW BEGIN
  	UPDATE `ru_catalog` 
	SET `popularity`=(SELECT COUNT(*) FROM `order_products` op WHERE op.`pid`=NEW.`pid`) 
	WHERE `id`=NEW.`pid`;
END	;
